package com.example.gramakhata

import android.net.Uri
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.example.gramakhata.databinding.ItemCustomerBinding

class CustomerAdapter(
    private var list: MutableList<Customer>,
    private val dbHelper: DatabaseHelper,
    private val onClick: (Customer) -> Unit,
    private val onLongClick: (Customer) -> Unit
) : RecyclerView.Adapter<CustomerAdapter.ViewHolder>() {

    private var filteredList = list.toMutableList()

    inner class ViewHolder(val binding: ItemCustomerBinding) :
        RecyclerView.ViewHolder(binding.root)

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int) = ViewHolder(
        ItemCustomerBinding.inflate(LayoutInflater.from(parent.context), parent, false)
    )

    override fun getItemCount() = filteredList.size

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val customer = filteredList[position]
        val balance = dbHelper.getBalance(customer.id)

        holder.binding.tvName.text = customer.name
        holder.binding.tvPhone.text = "📞 ${customer.phone}"

        // Show photo if available
        if (customer.photoUri.isNotEmpty()) {
            try {
                holder.binding.ivPhoto.setImageURI(Uri.parse(customer.photoUri))
                holder.binding.ivPhoto.setPadding(0, 0, 0, 0)
            } catch (e: Exception) {
                holder.binding.ivPhoto.setImageResource(android.R.drawable.ic_menu_camera)
            }
        } else {
            holder.binding.ivPhoto.setImageResource(android.R.drawable.ic_menu_camera)
        }

        when {
            balance > 0 -> {
                holder.binding.tvBalance.text = "Due\n₹${"%.2f".format(balance)}"
                holder.binding.tvBalance.setTextColor(0xFFD32F2F.toInt())
            }
            balance < 0 -> {
                holder.binding.tvBalance.text = "Adv\n₹${"%.2f".format(-balance)}"
                holder.binding.tvBalance.setTextColor(0xFF388E3C.toInt())
            }
            else -> {
                holder.binding.tvBalance.text = "✅ Clear"
                holder.binding.tvBalance.setTextColor(0xFF757575.toInt())
            }
        }

        holder.itemView.setOnClickListener { onClick(customer) }
        holder.itemView.setOnLongClickListener { onLongClick(customer); true }
    }

    fun updateList(newList: MutableList<Customer>) {
        list = newList
        filteredList = newList.toMutableList()
        notifyDataSetChanged()
    }

    fun filter(text: String) {
        filteredList = if (text.isEmpty()) list.toMutableList()
        else list.filter { it.name.contains(text, true) || it.phone.contains(text) }.toMutableList()
        notifyDataSetChanged()
    }
}
