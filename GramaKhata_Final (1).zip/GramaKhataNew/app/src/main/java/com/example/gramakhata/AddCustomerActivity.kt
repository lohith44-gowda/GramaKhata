package com.example.gramakhata

import android.Manifest
import android.content.ContentValues
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.provider.MediaStore
import android.text.Editable
import android.text.TextWatcher
import android.view.View
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.core.content.FileProvider
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.gramakhata.databinding.ActivityAddCustomerBinding
import com.example.gramakhata.databinding.DialogAddCustomerBinding
import java.io.File
import java.text.SimpleDateFormat
import java.util.*

class AddCustomerActivity : AppCompatActivity() {

    private lateinit var binding: ActivityAddCustomerBinding
    private lateinit var db: DatabaseHelper
    private lateinit var session: SessionManager
    private lateinit var adapter: CustomerAdapter
    private var customerList = mutableListOf<Customer>()
    private var selectedPhotoUri: Uri? = null
    private var currentPhotoPath: String = ""
    private var dialogBinding: DialogAddCustomerBinding? = null
    private var userId = -1

    private val pickImageLauncher = registerForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        uri?.let {
            // Copy to app's permanent internal storage so it survives gallery changes
            val permanentUri = copyToInternalStorage(it)
            selectedPhotoUri = permanentUri
            dialogBinding?.ivCustomerPhoto?.setImageURI(permanentUri)
            dialogBinding?.ivCustomerPhoto?.visibility = View.VISIBLE
        }
    }

    private val cameraLauncher = registerForActivityResult(ActivityResultContracts.TakePicture()) { success ->
        if (success && currentPhotoPath.isNotEmpty()) {
            val file = File(currentPhotoPath)
            // Save to gallery as well
            saveToGallery(file)
            selectedPhotoUri = Uri.fromFile(file)
            dialogBinding?.ivCustomerPhoto?.setImageURI(selectedPhotoUri)
            dialogBinding?.ivCustomerPhoto?.visibility = View.VISIBLE
        }
    }

    private val permissionLauncher = registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { perms ->
        if (perms[Manifest.permission.CAMERA] == true) launchCamera()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityAddCustomerBinding.inflate(layoutInflater)
        setContentView(binding.root)

        db = DatabaseHelper(this)
        session = SessionManager(this)
        userId = session.getUserId()

        if (userId == -1) {
            startActivity(Intent(this, LoginActivity::class.java))
            finish(); return
        }

        adapter = CustomerAdapter(mutableListOf(), db,
            { customer -> openCustomerDetail(customer) },
            { customer -> showOptionsDialog(customer) }
        )
        binding.recyclerView.layoutManager = LinearLayoutManager(this)
        binding.recyclerView.adapter = adapter

        refreshList()

        binding.fabAdd.setOnClickListener { showAddCustomerDialog() }
        binding.btnDueDashboard.setOnClickListener {
            startActivity(Intent(this, DueDashboardActivity::class.java))
        }

        // Store photo click
        binding.ivStoreLogo.setOnClickListener { pickStorePhoto() }

        binding.btnLogout.setOnClickListener {
            AlertDialog.Builder(this)
                .setTitle("Logout")
                .setMessage("Are you sure? Your data will remain safe.")
                .setPositiveButton("Logout") { _, _ ->
                    session.logout()   // Only clears session — photos & DB data are NOT deleted
                    startActivity(Intent(this, LoginActivity::class.java).apply {
                        flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
                    })
                }
                .setNegativeButton("Cancel", null).show()
        }

        binding.etSearch.addTextChangedListener(object : TextWatcher {
            override fun afterTextChanged(s: Editable?) { adapter.filter(s.toString()) }
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {}
        })
    }

    override fun onResume() { super.onResume(); refreshList() }

    private fun refreshList() {
        // Filter by userId — each user sees only their own customers
        customerList = db.getAllCustomers(userId)
        adapter.updateList(customerList)
        binding.tvEmpty.visibility = if (customerList.isEmpty()) View.VISIBLE else View.GONE
        binding.tvStoreName.text = session.getStoreName()
        binding.tvStorePlace.text = "📍 ${session.getStorePlace()}"
        val storePhoto = session.getStorePhotoUri()
        if (storePhoto.isNotEmpty()) {
            try { binding.ivStoreLogo.setImageURI(Uri.parse(storePhoto)) } catch (e: Exception) { }
        }
        val totalDue = customerList.sumOf { c -> val b = db.getBalance(c.id); if (b > 0) b else 0.0 }
        binding.tvSummary.text = "Total Due: ₹${"%.2f".format(totalDue)} | ${customerList.size} Customers"
    }

    private val storePhotoLauncher = registerForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        uri?.let {
            val permanent = copyToInternalStorage(it, "store_${userId}.jpg")
            session.updateStorePhoto(permanent.toString())
            db.updateStorePhoto(userId, permanent.toString())
            binding.ivStoreLogo.setImageURI(permanent)
            Toast.makeText(this, "Store photo updated!", Toast.LENGTH_SHORT).show()
        }
    }

    private fun pickStorePhoto() {
        AlertDialog.Builder(this)
            .setTitle("Store Photo")
            .setItems(arrayOf("Pick from Gallery", "Take Photo")) { _, which ->
                if (which == 0) storePhotoLauncher.launch("image/*")
                else {
                    checkCameraPermission(forStore = true)
                }
            }.show()
    }

    private var storePhotoMode = false

    private val storeCameraLauncher = registerForActivityResult(ActivityResultContracts.TakePicture()) { success ->
        if (success && currentPhotoPath.isNotEmpty()) {
            val file = File(currentPhotoPath)
            saveToGallery(file)
            val uri = Uri.fromFile(file)
            session.updateStorePhoto(uri.toString())
            db.updateStorePhoto(userId, uri.toString())
            binding.ivStoreLogo.setImageURI(uri)
            Toast.makeText(this, "Store photo updated!", Toast.LENGTH_SHORT).show()
        }
    }

    private fun openCustomerDetail(customer: Customer) {
        startActivity(Intent(this, CustomerDetailActivity::class.java).apply {
            putExtra("customerId", customer.id)
            putExtra("customerName", customer.name)
            putExtra("customerPhone", customer.phone)
        })
    }

    private fun showOptionsDialog(customer: Customer) {
        AlertDialog.Builder(this)
            .setTitle(customer.name)
            .setItems(arrayOf("Call", "Edit", "Delete", "Send Reminder")) { _, which ->
                when (which) {
                    0 -> startActivity(Intent(Intent.ACTION_DIAL, Uri.parse("tel:${customer.phone}")))
                    1 -> showEditDialog(customer)
                    2 -> deleteCustomer(customer)
                    3 -> sendReminder(customer)
                }
            }.show()
    }

    private fun deleteCustomer(customer: Customer) {
        AlertDialog.Builder(this)
            .setTitle("Delete ${customer.name}?")
            .setMessage("All transactions will be removed.")
            .setPositiveButton("Delete") { _, _ ->
                db.deleteCustomer(customer.id)
                refreshList()
                Toast.makeText(this, "Deleted", Toast.LENGTH_SHORT).show()
            }
            .setNegativeButton("Cancel", null).show()
    }

    private fun showEditDialog(customer: Customer) {
        selectedPhotoUri = if (customer.photoUri.isNotEmpty()) Uri.parse(customer.photoUri) else null
        val dlg = DialogAddCustomerBinding.inflate(layoutInflater)
        dialogBinding = dlg
        dlg.etName.setText(customer.name)
        dlg.etPhone.setText(customer.phone)
        if (customer.photoUri.isNotEmpty()) {
            try { dlg.ivCustomerPhoto.setImageURI(Uri.parse(customer.photoUri)); dlg.ivCustomerPhoto.visibility = View.VISIBLE }
            catch (e: Exception) { }
        }
        dlg.btnCamera.setOnClickListener { checkCameraPermission() }
        dlg.btnGallery.setOnClickListener { pickImageLauncher.launch("image/*") }

        AlertDialog.Builder(this).setTitle("Edit Customer").setView(dlg.root)
            .setPositiveButton("Update") { _, _ ->
                val n = dlg.etName.text.toString().trim()
                val p = dlg.etPhone.text.toString().trim()
                if (n.isNotEmpty() && p.isNotEmpty()) {
                    db.updateCustomer(customer.id, n, p, selectedPhotoUri?.toString() ?: customer.photoUri)
                    refreshList(); Toast.makeText(this, "Updated", Toast.LENGTH_SHORT).show()
                }
                dialogBinding = null; selectedPhotoUri = null
            }
            .setNegativeButton("Cancel") { _, _ -> dialogBinding = null; selectedPhotoUri = null }
            .show()
    }

    private fun showAddCustomerDialog() {
        selectedPhotoUri = null
        val dlg = DialogAddCustomerBinding.inflate(layoutInflater)
        dialogBinding = dlg
        dlg.btnCamera.setOnClickListener { checkCameraPermission() }
        dlg.btnGallery.setOnClickListener { pickImageLauncher.launch("image/*") }

        val dialog = AlertDialog.Builder(this).setTitle("Add Customer").setView(dlg.root)
            .setPositiveButton("Save", null)
            .setNegativeButton("Cancel") { _, _ -> dialogBinding = null; selectedPhotoUri = null }
            .create()

        dialog.setOnShowListener {
            dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener {
                val n = dlg.etName.text.toString().trim()
                val p = dlg.etPhone.text.toString().trim()
                if (n.isEmpty() || p.isEmpty()) { Toast.makeText(this, "Enter name & phone", Toast.LENGTH_SHORT).show(); return@setOnClickListener }
                // Pass userId so data is scoped to this user
                if (db.insertCustomer(userId, n, p, selectedPhotoUri?.toString() ?: "")) {
                    Toast.makeText(this, "Customer saved!", Toast.LENGTH_SHORT).show()
                    refreshList(); dialog.dismiss()
                }
                dialogBinding = null; selectedPhotoUri = null
            }
        }
        dialog.show()
    }

    private fun checkCameraPermission(forStore: Boolean = false) {
        storePhotoMode = forStore
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED)
            if (forStore) launchStoreCamera() else launchCamera()
        else permissionLauncher.launch(arrayOf(Manifest.permission.CAMERA))
    }

    private fun launchCamera() {
        val file = createImageFile("CUSTOMER")
        val uri = FileProvider.getUriForFile(this, "${packageName}.provider", file)
        currentPhotoPath = file.absolutePath
        cameraLauncher.launch(uri)
    }

    private fun launchStoreCamera() {
        val file = createImageFile("STORE")
        val uri = FileProvider.getUriForFile(this, "${packageName}.provider", file)
        currentPhotoPath = file.absolutePath
        storeCameraLauncher.launch(uri)
    }

    /** Creates image in internal app files — survives logout */
    private fun createImageFile(prefix: String): File {
        val ts = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.getDefault()).format(Date())
        val dir = File(filesDir, "photos").also { it.mkdirs() }
        return File(dir, "${prefix}_${userId}_${ts}.jpg")
    }

    /** Also saves a copy to device gallery for user access */
    private fun saveToGallery(file: File) {
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                val values = ContentValues().apply {
                    put(MediaStore.Images.Media.DISPLAY_NAME, file.name)
                    put(MediaStore.Images.Media.MIME_TYPE, "image/jpeg")
                    put(MediaStore.Images.Media.RELATIVE_PATH, Environment.DIRECTORY_PICTURES + "/GramaKhata")
                }
                val uri = contentResolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values)
                uri?.let { dest ->
                    contentResolver.openOutputStream(dest)?.use { out ->
                        file.inputStream().use { it.copyTo(out) }
                    }
                }
            } else {
                val dest = File(Environment.getExternalStoragePublicDirectory(
                    Environment.DIRECTORY_PICTURES), "GramaKhata").also { it.mkdirs() }
                file.copyTo(File(dest, file.name), overwrite = true)
            }
        } catch (e: Exception) { /* gallery save failed silently */ }
    }

    /** Copies a URI picked from gallery into internal storage */
    private fun copyToInternalStorage(uri: Uri, name: String? = null): Uri {
        val ts = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.getDefault()).format(Date())
        val dir = File(filesDir, "photos").also { it.mkdirs() }
        val dest = File(dir, name ?: "PICKED_${userId}_${ts}.jpg")
        contentResolver.openInputStream(uri)?.use { input ->
            dest.outputStream().use { output -> input.copyTo(output) }
        }
        return Uri.fromFile(dest)
    }

    private fun sendReminder(customer: Customer) {
        val balance = db.getBalance(customer.id)
        if (balance == 0.0) { Toast.makeText(this, "No outstanding balance", Toast.LENGTH_SHORT).show(); return }
        val shopName = session.getStoreName()
        val message = "Namaskara, your due at $shopName is Rs.${"%.2f".format(balance)}. Please pay when possible. - $shopName"
        AlertDialog.Builder(this).setTitle("Send Reminder")
            .setItems(arrayOf("WhatsApp", "SMS")) { _, which ->
                var phone = customer.phone.trimStart('0')
                if (!phone.startsWith("91")) phone = "91$phone"
                when (which) {
                    0 -> startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://wa.me/$phone?text=${Uri.encode(message)}")))
                    1 -> startActivity(Intent(Intent.ACTION_VIEW).apply {
                        data = Uri.parse("sms:${customer.phone}"); putExtra("sms_body", message)
                    })
                }
            }.show()
    }
}
