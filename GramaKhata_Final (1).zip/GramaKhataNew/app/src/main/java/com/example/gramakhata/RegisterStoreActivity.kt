package com.example.gramakhata

import android.content.Intent
import android.os.Bundle
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.example.gramakhata.databinding.ActivityRegisterStoreBinding

class RegisterStoreActivity : AppCompatActivity() {

    private lateinit var binding: ActivityRegisterStoreBinding
    private lateinit var db: DatabaseHelper
    private lateinit var session: SessionManager

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityRegisterStoreBinding.inflate(layoutInflater)
        setContentView(binding.root)

        db      = DatabaseHelper(this)
        session = SessionManager(this)

        val phone    = intent.getStringExtra("phone") ?: ""
        val password = intent.getStringExtra("password") ?: ""

        binding.tvPhone.text = "Phone: +91 $phone"

        binding.btnRegister.setOnClickListener {
            val storeName  = binding.etStoreName.text.toString().trim()
            val storePlace = binding.etStorePlace.text.toString().trim()

            if (storeName.isEmpty())  { binding.etStoreName.error  = "Enter store name"; return@setOnClickListener }
            if (storePlace.isEmpty()) { binding.etStorePlace.error = "Enter place/city"; return@setOnClickListener }

            val success = db.registerUser(phone, password, storeName, storePlace)
            if (success) {
                // Fetch the newly created user to get the auto-generated userId
                val newUser = db.getUserByPhone(phone)
                if (newUser != null) {
                    session.saveSession(newUser)   // saves userId so data is properly scoped
                    Toast.makeText(this, "Welcome, $storeName!", Toast.LENGTH_LONG).show()
                    startActivity(Intent(this, AddCustomerActivity::class.java).apply {
                        flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
                    })
                } else {
                    Toast.makeText(this, "Registration error. Please login.", Toast.LENGTH_SHORT).show()
                    startActivity(Intent(this, LoginActivity::class.java).apply {
                        flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
                    })
                }
            } else {
                Toast.makeText(this, "Registration failed. Phone may already be registered.", Toast.LENGTH_SHORT).show()
            }
        }
    }
}
