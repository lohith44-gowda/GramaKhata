package com.example.gramakhata

import android.os.Bundle
import android.os.CountDownTimer
import android.text.InputType
import android.view.View
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.example.gramakhata.databinding.ActivityForgotPasswordBinding
import android.content.Intent

class ForgotPasswordActivity : AppCompatActivity() {

    private lateinit var binding: ActivityForgotPasswordBinding
    private lateinit var db: DatabaseHelper
    private var verifiedPhone = ""
    private var countDownTimer: CountDownTimer? = null
    private var newPassVisible = false
    private var confirmPassVisible = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityForgotPasswordBinding.inflate(layoutInflater)
        setContentView(binding.root)
        db = DatabaseHelper(this)
        showPhoneScreen()

        // Step 1 — Send OTP directly via SMS
        binding.btnSendOtp.setOnClickListener {
            val phone = binding.etPhone.text.toString().trim()
            if (phone.length != 10 || !phone.all { it.isDigit() }) {
                binding.etPhone.error = "Enter valid 10-digit phone number"; return@setOnClickListener
            }
            if (db.getUserByPhone(phone) == null) {
                binding.etPhone.error = "Phone number not registered"; return@setOnClickListener
            }
            binding.btnSendOtp.isEnabled = false
            binding.btnSendOtp.text = "Sending OTP..."

            // Send directly — no user action needed
            val sent = OtpManager.sendOtpDirectSms(this, phone)
            if (sent) {
                verifiedPhone = phone
                Toast.makeText(this, "OTP sent to $phone via SMS", Toast.LENGTH_LONG).show()
                showOtpScreen(phone)
            } else {
                binding.btnSendOtp.isEnabled = true
                binding.btnSendOtp.text = "SEND OTP"
                Toast.makeText(this, "Could not send SMS. Check SEND_SMS permission.", Toast.LENGTH_LONG).show()
            }
        }

        // Step 2 — Verify OTP
        binding.btnVerifyOtp.setOnClickListener {
            val entered = binding.etOtp.text.toString().trim()
            if (entered.length != 6) { binding.etOtp.error = "Enter 6-digit OTP"; return@setOnClickListener }
            when (OtpManager.verifyOtp(verifiedPhone, entered)) {
                OtpManager.OtpResult.SUCCESS -> {
                    countDownTimer?.cancel()
                    Toast.makeText(this, "OTP Verified!", Toast.LENGTH_SHORT).show()
                    showResetScreen()
                }
                OtpManager.OtpResult.EXPIRED -> {
                    Toast.makeText(this, "OTP expired. Request a new one.", Toast.LENGTH_SHORT).show()
                    binding.btnResendOtp.visibility = View.VISIBLE
                    binding.btnVerifyOtp.isEnabled = false
                }
                OtpManager.OtpResult.WRONG_OTP -> binding.etOtp.error = "Incorrect OTP. Try again."
                else -> Toast.makeText(this, "Something went wrong.", Toast.LENGTH_SHORT).show()
            }
        }

        // Resend OTP
        binding.btnResendOtp.setOnClickListener {
            binding.btnResendOtp.isEnabled = false
            binding.btnResendOtp.text = "Sending..."
            val sent = OtpManager.sendOtpDirectSms(this, verifiedPhone)
            binding.btnResendOtp.isEnabled = true
            binding.btnResendOtp.text = "Resend OTP"
            if (sent) {
                Toast.makeText(this, "New OTP sent!", Toast.LENGTH_SHORT).show()
                binding.btnResendOtp.visibility = View.GONE
                binding.btnVerifyOtp.isEnabled = true
                startCountdown()
            }
        }

        // Toggle password visibility
        binding.btnToggleNew.setOnClickListener {
            newPassVisible = !newPassVisible
            binding.etNewPassword.inputType = if (newPassVisible)
                InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD
            else InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
            binding.etNewPassword.setSelection(binding.etNewPassword.text?.length ?: 0)
            binding.btnToggleNew.text = if (newPassVisible) "HIDE" else "SHOW"
        }
        binding.btnToggleConfirm.setOnClickListener {
            confirmPassVisible = !confirmPassVisible
            binding.etConfirmNewPassword.inputType = if (confirmPassVisible)
                InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD
            else InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
            binding.etConfirmNewPassword.setSelection(binding.etConfirmNewPassword.text?.length ?: 0)
            binding.btnToggleConfirm.text = if (confirmPassVisible) "HIDE" else "SHOW"
        }

        // Step 3 — Reset password
        binding.btnResetPassword.setOnClickListener {
            val newPass = binding.etNewPassword.text.toString().trim()
            val confirm = binding.etConfirmNewPassword.text.toString().trim()
            val err = validatePassword(newPass)
            if (err != null) { binding.etNewPassword.error = err; return@setOnClickListener }
            if (newPass != confirm) { binding.etConfirmNewPassword.error = "Passwords do not match"; return@setOnClickListener }
            if (db.updatePassword(verifiedPhone, newPass)) {
                OtpManager.clearOtp()
                Toast.makeText(this, "Password reset! Please login.", Toast.LENGTH_LONG).show()
                startActivity(Intent(this, LoginActivity::class.java).apply {
                    flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
                })
            } else Toast.makeText(this, "Failed. Try again.", Toast.LENGTH_SHORT).show()
        }

        binding.tvBackToLogin.setOnClickListener { finish() }
    }

    private fun showPhoneScreen() {
        binding.layoutPhone.visibility = View.VISIBLE
        binding.layoutOtp.visibility   = View.GONE
        binding.layoutReset.visibility = View.GONE
        binding.tvStep.text = "Step 1 of 3 — Enter registered phone"
    }

    private fun showOtpScreen(phone: String) {
        binding.layoutPhone.visibility = View.GONE
        binding.layoutOtp.visibility   = View.VISIBLE
        binding.layoutReset.visibility = View.GONE
        binding.tvStep.text = "Step 2 of 3 — OTP sent to $phone"
        binding.btnResendOtp.visibility = View.GONE
        binding.btnVerifyOtp.isEnabled  = true
        startCountdown()
    }

    private fun showResetScreen() {
        binding.layoutPhone.visibility = View.GONE
        binding.layoutOtp.visibility   = View.GONE
        binding.layoutReset.visibility = View.VISIBLE
        binding.tvStep.text = "Step 3 of 3 — Create new password"
    }

    private fun startCountdown() {
        countDownTimer?.cancel()
        countDownTimer = object : CountDownTimer(5 * 60 * 1000L, 1000L) {
            override fun onTick(ms: Long) {
                val m = ms / 60000; val s = (ms % 60000) / 1000
                binding.tvOtpTimer.text = "OTP expires in %02d:%02d".format(m, s)
            }
            override fun onFinish() {
                binding.tvOtpTimer.text = "OTP expired"
                binding.btnResendOtp.visibility = View.VISIBLE
                binding.btnVerifyOtp.isEnabled  = false
            }
        }.start()
    }

    private fun validatePassword(p: String): String? {
        if (p.length < 8)                        return "Minimum 8 characters"
        if (!p.any { it.isUpperCase() })          return "Add one uppercase letter"
        if (!p.any { it.isLowerCase() })          return "Add one lowercase letter"
        if (!p.any { it.isDigit() })              return "Add one number"
        if (!p.any { "!@#\$%^&*()_+-=".contains(it) }) return "Add one special char (!@#\$)"
        return null
    }

    override fun onDestroy() { super.onDestroy(); countDownTimer?.cancel() }
}
