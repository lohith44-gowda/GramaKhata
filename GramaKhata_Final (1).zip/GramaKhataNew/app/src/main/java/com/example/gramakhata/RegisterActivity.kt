package com.example.gramakhata

import android.content.Intent
import android.os.Bundle
import android.text.Editable
import android.text.InputType
import android.text.TextWatcher
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.example.gramakhata.databinding.ActivityRegisterBinding

class RegisterActivity : AppCompatActivity() {

    private lateinit var binding: ActivityRegisterBinding
    private lateinit var db: DatabaseHelper
    private var passwordVisible = false
    private var confirmVisible = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityRegisterBinding.inflate(layoutInflater)
        setContentView(binding.root)

        db = DatabaseHelper(this)

        binding.btnTogglePassword.setOnClickListener {
            passwordVisible = !passwordVisible
            binding.etPassword.inputType = if (passwordVisible)
                InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD
            else InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
            binding.etPassword.setSelection(binding.etPassword.text?.length ?: 0)
            binding.btnTogglePassword.text = if (passwordVisible) "HIDE" else "SHOW"
        }

        binding.btnToggleConfirm.setOnClickListener {
            confirmVisible = !confirmVisible
            binding.etConfirmPassword.inputType = if (confirmVisible)
                InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD
            else InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
            binding.etConfirmPassword.setSelection(binding.etConfirmPassword.text?.length ?: 0)
            binding.btnToggleConfirm.text = if (confirmVisible) "HIDE" else "SHOW"
        }

        // Live password strength checker
        binding.etPassword.addTextChangedListener(object : TextWatcher {
            override fun afterTextChanged(s: Editable?) { checkPasswordStrength(s.toString()) }
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {}
        })

        binding.btnNext.setOnClickListener {
            val phone    = binding.etPhone.text.toString().trim()
            val password = binding.etPassword.text.toString().trim()
            val confirm  = binding.etConfirmPassword.text.toString().trim()

            if (phone.length != 10 || !phone.all { it.isDigit() }) {
                binding.etPhone.error = "Enter valid 10-digit phone number"
                return@setOnClickListener
            }

            val strengthError = validatePassword(password)
            if (strengthError != null) {
                binding.etPassword.error = strengthError
                return@setOnClickListener
            }

            if (password != confirm) {
                binding.etConfirmPassword.error = "Passwords do not match"
                return@setOnClickListener
            }

            if (db.getUserByPhone(phone) != null) {
                binding.etPhone.error = "Phone already registered. Please login."
                return@setOnClickListener
            }

            startActivity(Intent(this, RegisterStoreActivity::class.java).apply {
                putExtra("phone", phone)
                putExtra("password", password)
            })
        }

        binding.tvLogin.setOnClickListener { finish() }
    }

    private fun validatePassword(password: String): String? {
        if (password.length < 8)
            return "Minimum 8 characters required"
        if (!password.any { it.isUpperCase() })
            return "Must have at least one uppercase letter (e.g. A)"
        if (!password.any { it.isLowerCase() })
            return "Must have at least one lowercase letter"
        if (!password.any { it.isDigit() })
            return "Must include at least one number (0-9)"
        if (!password.any { "!@#\$%^&*()_+-=[]{}|;:,.<>?".contains(it) })
            return "Must include a special character (e.g. @, #, \$)"
        return null
    }

    private fun checkPasswordStrength(password: String) {
        val hasUpper   = password.any { it.isUpperCase() }
        val hasLower   = password.any { it.isLowerCase() }
        val hasDigit   = password.any { it.isDigit() }
        val hasSpecial = password.any { "!@#\$%^&*()_+-=[]{}|;:,.<>?".contains(it) }
        val hasLength  = password.length >= 8

        val score = listOf(hasUpper, hasLower, hasDigit, hasSpecial, hasLength).count { it }

        val (text, color) = when {
            password.isEmpty() -> Pair(
                "Requirements:\n• Capital letter  • Number  • Special char (!@#\$)",
                0xFF888888.toInt()
            )
            score <= 2 -> Pair("🔴 Weak password", 0xFFD32F2F.toInt())
            score == 3 -> Pair("🟡 Medium password", 0xFFF57F17.toInt())
            score == 4 -> Pair("🟠 Good password", 0xFFE65100.toInt())
            else       -> Pair("🟢 Strong password ✓", 0xFF388E3C.toInt())
        }

        val hints = buildString {
            appendLine(if (hasLength)  "  ✓ 8+ characters"        else "  ✗ At least 8 characters")
            appendLine(if (hasUpper)   "  ✓ Uppercase letter"     else "  ✗ One uppercase letter (A-Z)")
            appendLine(if (hasLower)   "  ✓ Lowercase letter"     else "  ✗ One lowercase letter (a-z)")
            appendLine(if (hasDigit)   "  ✓ Number"               else "  ✗ One number (0-9)")
            append(    if (hasSpecial) "  ✓ Special character"    else "  ✗ One special char (!@#\$...)")
        }

        binding.tvPasswordStrength.text = "$text\n$hints"
        binding.tvPasswordStrength.setTextColor(color)
    }
}
