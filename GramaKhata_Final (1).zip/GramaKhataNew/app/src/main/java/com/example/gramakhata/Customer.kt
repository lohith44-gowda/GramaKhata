package com.example.gramakhata

data class Customer(
    val id: Int,
    val name: String,
    val phone: String,
    val photoUri: String = ""
)
