package com.example.gramakhata

import android.content.Intent
import android.os.Bundle
import android.text.InputType
import android.text.SpannableString
import android.text.style.UnderlineSpan
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.example.gramakhata.databinding.ActivityLoginBinding

class LoginActivity : AppCompatActivity() {

    private lateinit var binding: ActivityLoginBinding
    private lateinit var db: DatabaseHelper
    private lateinit var session: SessionManager
    private var passwordVisible = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityLoginBinding.inflate(layoutInflater)
        setContentView(binding.root)

        db      = DatabaseHelper(this)
        session = SessionManager(this)

        if (session.isLoggedIn()) { goToMain(); return }

        // tvForgotPassword is a TextView so keep underline
        binding.tvForgotPassword.text = SpannableString("Forgot Password?").also {
            it.setSpan(UnderlineSpan(), 0, it.length, 0)
        }

        binding.btnTogglePassword.setOnClickListener {
            passwordVisible = !passwordVisible
            binding.etPassword.inputType = if (passwordVisible)
                InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD
            else InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
            binding.etPassword.setSelection(binding.etPassword.text?.length ?: 0)
            binding.btnTogglePassword.text = if (passwordVisible) "HIDE" else "SHOW"
        }

        binding.btnLogin.setOnClickListener {
            val phone    = binding.etPhone.text.toString().trim()
            val password = binding.etPassword.text.toString().trim()
            if (phone.isEmpty() || password.isEmpty()) {
                Toast.makeText(this, "Enter phone and password", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }
            if (phone.length != 10) {
                Toast.makeText(this, "Enter valid 10-digit phone", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }
            val user = db.loginUser(phone, password)
            if (user != null) {
                session.saveSession(user)
                Toast.makeText(this, "Welcome, ${user.storeName}!", Toast.LENGTH_SHORT).show()
                goToMain()
            } else {
                Toast.makeText(this, "Invalid phone or password", Toast.LENGTH_SHORT).show()
            }
        }

        // tvRegister is now a Button in the new design
        binding.tvRegister.setOnClickListener {
            startActivity(Intent(this, RegisterActivity::class.java))
        }
        binding.tvForgotPassword.setOnClickListener {
            startActivity(Intent(this, ForgotPasswordActivity::class.java))
        }
    }

    private fun goToMain() {
        startActivity(Intent(this, AddCustomerActivity::class.java))
        finish()
    }
}
