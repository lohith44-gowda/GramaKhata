package com.example.gramakhata

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.widget.*
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.gramakhata.databinding.ActivityCustomerDetailBinding
import java.text.SimpleDateFormat
import java.util.*

class CustomerDetailActivity : AppCompatActivity() {

    private lateinit var binding: ActivityCustomerDetailBinding
    private lateinit var db: DatabaseHelper
    private lateinit var session: SessionManager
    private lateinit var adapter: TransactionAdapter
    private var customerId = 0
    private var customerName = ""
    private var customerPhone = ""
    private var shopName = ""

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityCustomerDetailBinding.inflate(layoutInflater)
        setContentView(binding.root)

        db = DatabaseHelper(this)
        session = SessionManager(this)

        customerId   = intent.getIntExtra("customerId", 0)
        customerName = intent.getStringExtra("customerName") ?: ""
        customerPhone= intent.getStringExtra("customerPhone") ?: ""
        // Always use logged-in store's name for reminder messages
        shopName     = session.getStoreName()

        binding.tvName.text  = customerName
        binding.tvPhone.text = "📞 $customerPhone"

        adapter = TransactionAdapter(db.getTransactions(customerId))
        binding.recyclerTransactions.layoutManager = LinearLayoutManager(this)
        binding.recyclerTransactions.adapter = adapter

        updateBalance()

        binding.btnGive.setOnClickListener   { showTransactionDialog("GIVE") }
        binding.btnTake.setOnClickListener   { showTransactionDialog("TAKE") }
        binding.btnWhatsApp.setOnClickListener { sendWhatsApp() }
        binding.btnReport.setOnClickListener   { showDailyReport() }
        binding.btnBack.setOnClickListener     { finish() }
    }

    private fun showTransactionDialog(type: String) {
        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(48, 32, 48, 16)
        }
        val etAmount = EditText(this).apply {
            hint = "Amount (₹)"
            inputType = android.text.InputType.TYPE_CLASS_NUMBER or android.text.InputType.TYPE_NUMBER_FLAG_DECIMAL
        }
        val etNote = EditText(this).apply { hint = "Note (optional)" }
        layout.addView(etAmount)
        layout.addView(etNote)

        val title = if (type == "GIVE") "📤 Give Credit (Koduvudu)" else "📥 Receive Payment (Tegedukolluvudu)"

        AlertDialog.Builder(this)
            .setTitle(title)
            .setView(layout)
            .setPositiveButton("Save") { _, _ ->
                val amtStr = etAmount.text.toString().trim()
                if (amtStr.isEmpty()) { Toast.makeText(this, "Enter amount", Toast.LENGTH_SHORT).show(); return@setPositiveButton }
                val amount = amtStr.toDoubleOrNull() ?: 0.0
                if (amount <= 0) { Toast.makeText(this, "Enter valid amount", Toast.LENGTH_SHORT).show(); return@setPositiveButton }
                val date = SimpleDateFormat("dd MMM yyyy, hh:mm a", Locale.getDefault()).format(Date())
                db.addTransaction(customerId, amount, type, date, etNote.text.toString().trim())
                refresh()
                Toast.makeText(this, if (type == "GIVE") "Credit ₹${"%.2f".format(amount)} added" else "Payment ₹${"%.2f".format(amount)} recorded", Toast.LENGTH_SHORT).show()
            }
            .setNegativeButton("Cancel", null).show()
    }

    private fun refresh() { adapter.update(db.getTransactions(customerId)); updateBalance() }

    private fun updateBalance() {
        val balance = db.getBalance(customerId)
        when {
            balance > 0 -> { binding.tvBalance.text = "Net Due: ₹${"%.2f".format(balance)}"; binding.tvBalance.setTextColor(0xFFD32F2F.toInt()) }
            balance < 0 -> { binding.tvBalance.text = "Advance Paid: ₹${"%.2f".format(-balance)}"; binding.tvBalance.setTextColor(0xFF388E3C.toInt()) }
            else        -> { binding.tvBalance.text = "✅ All Clear"; binding.tvBalance.setTextColor(0xFF388E3C.toInt()) }
        }
    }

    private fun sendWhatsApp() {
        val balance = db.getBalance(customerId)
        if (balance == 0.0) { Toast.makeText(this, "No outstanding balance", Toast.LENGTH_SHORT).show(); return }

        // Message always uses the logged-in store's name
        val message = "Namaskara 🙏 $customerName, your due at $shopName is ₹${"%.2f".format(balance)}. Please pay when convenient.\n- $shopName"

        AlertDialog.Builder(this)
            .setTitle("Send Reminder from $shopName")
            .setItems(arrayOf("💬 WhatsApp", "📨 SMS")) { _, which ->
                var phone = customerPhone.trimStart('0')
                if (!phone.startsWith("91")) phone = "91$phone"
                when (which) {
                    0 -> try {
                        startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://wa.me/$phone?text=${Uri.encode(message)}")))
                    } catch (e: Exception) {
                        startActivity(Intent(Intent.ACTION_VIEW).apply { data = Uri.parse("sms:$customerPhone"); putExtra("sms_body", message) })
                    }
                    1 -> startActivity(Intent(Intent.ACTION_VIEW).apply { data = Uri.parse("sms:$customerPhone"); putExtra("sms_body", message) })
                }
            }.show()
    }

    private fun showDailyReport() {
        val transactions = db.getTransactions(customerId)
        val balance = db.getBalance(customerId)
        val sb = StringBuilder()
        sb.appendLine("=== $shopName ===")
        sb.appendLine("Customer: $customerName")
        sb.appendLine("Phone: $customerPhone")
        sb.appendLine("Net Balance: ₹${"%.2f".format(balance)}")
        sb.appendLine("---")
        transactions.take(10).forEach { t ->
            sb.appendLine("${t.date}: ${t.type} ₹${"%.2f".format(t.amount)}" + if (t.note.isNotEmpty()) " (${t.note})" else "")
        }
        AlertDialog.Builder(this)
            .setTitle("📄 Report — $shopName")
            .setMessage(sb.toString())
            .setPositiveButton("OK", null).show()
    }
}
