package com.example.gramakhata

data class User(
    val id: Int,
    val phone: String,
    val password: String,
    val storeName: String,
    val storePlace: String,
    val storePhotoUri: String = ""
)
