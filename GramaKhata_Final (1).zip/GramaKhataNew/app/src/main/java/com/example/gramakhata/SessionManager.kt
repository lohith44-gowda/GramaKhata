package com.example.gramakhata

import android.content.Context
import android.content.SharedPreferences

class SessionManager(context: Context) {
    private val prefs: SharedPreferences =
        context.getSharedPreferences("GramaKhataSession", Context.MODE_PRIVATE)

    fun saveSession(user: com.example.gramakhata.User) {
        prefs.edit().apply {
            putInt("userId", user.id)
            putString("phone", user.phone)
            putString("storeName", user.storeName)
            putString("storePlace", user.storePlace)
            putString("storePhotoUri", user.storePhotoUri)
            putBoolean("isLoggedIn", true)
            apply()
        }
    }

    fun isLoggedIn() = prefs.getBoolean("isLoggedIn", false)
    fun getUserId() = prefs.getInt("userId", -1)
    fun getPhone() = prefs.getString("phone", "") ?: ""
    fun getStoreName() = prefs.getString("storeName", "My Store") ?: "My Store"
    fun getStorePlace() = prefs.getString("storePlace", "") ?: ""
    fun getStorePhotoUri() = prefs.getString("storePhotoUri", "") ?: ""

    fun updateStorePhoto(uri: String) {
        prefs.edit().putString("storePhotoUri", uri).apply()
    }

    // Logout only clears session — does NOT delete any files or data
    fun logout() = prefs.edit().clear().apply()
}
