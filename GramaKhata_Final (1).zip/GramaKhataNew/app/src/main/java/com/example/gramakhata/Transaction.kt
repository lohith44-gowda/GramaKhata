package com.example.gramakhata

data class Transaction(
    val id: Int,
    val customerId: Int,
    val amount: Double,
    val type: String,
    val date: String,
    val note: String = ""
)
