package com.example.gramakhata

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.view.LayoutInflater
import android.view.ViewGroup
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.gramakhata.databinding.ActivityDueDashboardBinding
import com.example.gramakhata.databinding.ItemCustomerBinding

class DueDashboardActivity : AppCompatActivity() {
    private lateinit var binding: ActivityDueDashboardBinding
    private lateinit var db: DatabaseHelper
    private lateinit var session: SessionManager
    private var shopName = ""
    private var userId = -1

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityDueDashboardBinding.inflate(layoutInflater)
        setContentView(binding.root)
        db = DatabaseHelper(this); session = SessionManager(this)
        shopName = session.getStoreName()
        userId = session.getUserId()
        binding.tvShopName.text = "Due Dashboard - $shopName"
        binding.btnBack.setOnClickListener { finish() }
        binding.btnGenerateReport.setOnClickListener { generateReport() }
        loadDashboard()
    }

    private fun loadDashboard() {
        // Only loads dues for the logged-in user's customers
        val dueList = db.getAllDueSummary(userId)
        binding.tvTotalDue.text = "Total: Rs.${"%.2f".format(dueList.sumOf { it.second })}"
        binding.tvCustomerCount.text = "${dueList.size} customers with dues"

        val adapter = object : RecyclerView.Adapter<RecyclerView.ViewHolder>() {
            inner class VH(val b: ItemCustomerBinding) : RecyclerView.ViewHolder(b.root)
            override fun onCreateViewHolder(p: ViewGroup, v: Int) =
                VH(ItemCustomerBinding.inflate(LayoutInflater.from(p.context), p, false))
            override fun getItemCount() = dueList.size
            override fun onBindViewHolder(h: RecyclerView.ViewHolder, i: Int) {
                val vh = h as VH; val (c, bal, _) = dueList[i]
                vh.b.tvName.text = c.name; vh.b.tvPhone.text = c.phone
                vh.b.tvBalance.text = "Due: Rs.${"%.2f".format(bal)}"
                vh.b.tvBalance.setTextColor(0xFFD32F2F.toInt())
                vh.b.root.setOnClickListener {
                    startActivity(Intent(this@DueDashboardActivity, CustomerDetailActivity::class.java).apply {
                        putExtra("customerId", c.id); putExtra("customerName", c.name); putExtra("customerPhone", c.phone)
                    })
                }
                vh.b.root.setOnLongClickListener {
                    val msg = "Namaskara ${c.name}, your due at $shopName is Rs.${"%.2f".format(bal)}. - $shopName"
                    var ph = c.phone.trimStart('0'); if (!ph.startsWith("91")) ph = "91$ph"
                    AlertDialog.Builder(this@DueDashboardActivity).setTitle("Remind ${c.name}")
                        .setItems(arrayOf("WhatsApp", "SMS")) { _, w ->
                            if (w == 0) startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://wa.me/$ph?text=${Uri.encode(msg)}")))
                            else startActivity(Intent(Intent.ACTION_VIEW).apply { data = Uri.parse("sms:${c.phone}"); putExtra("sms_body", msg) })
                        }.show(); true
                }
            }
        }
        binding.rvDue.layoutManager = LinearLayoutManager(this)
        binding.rvDue.adapter = adapter
    }

    private fun generateReport() {
        val dueList = db.getAllDueSummary(userId)
        if (dueList.isEmpty()) { Toast.makeText(this, "No dues! All clear!", Toast.LENGTH_SHORT).show(); return }
        val sb = StringBuilder("=== Daily Report ===\nShop: $shopName\nPlace: ${session.getStorePlace()}\n---\n")
        dueList.forEach { (c, b, _) -> sb.appendLine("${c.name} (${c.phone}): Rs.${"%.2f".format(b)}") }
        sb.appendLine("---\nTotal: Rs.${"%.2f".format(dueList.sumOf { it.second })}")
        AlertDialog.Builder(this).setTitle("Daily Report - $shopName").setMessage(sb.toString()).setPositiveButton("OK", null).show()
    }
}
