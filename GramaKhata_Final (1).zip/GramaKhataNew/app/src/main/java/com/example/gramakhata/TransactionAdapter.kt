package com.example.gramakhata

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.example.gramakhata.databinding.ItemTransactionBinding

class TransactionAdapter(
    private var list: MutableList<Transaction>
) : RecyclerView.Adapter<TransactionAdapter.ViewHolder>() {

    inner class ViewHolder(val binding: ItemTransactionBinding) :
        RecyclerView.ViewHolder(binding.root)

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int) = ViewHolder(
        ItemTransactionBinding.inflate(LayoutInflater.from(parent.context), parent, false)
    )

    override fun getItemCount() = list.size

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val t = list[position]
        if (t.type == "GIVE") {
            holder.binding.tvType.text = "📤 Credit (Koduvudu)"
            holder.binding.tvAmount.text = "+₹${"%.2f".format(t.amount)}"
            holder.binding.tvAmount.setTextColor(0xFFD32F2F.toInt())
            holder.binding.tvType.setTextColor(0xFFD32F2F.toInt())
        } else {
            holder.binding.tvType.text = "📥 Payment (Tegedukolluvudu)"
            holder.binding.tvAmount.text = "-₹${"%.2f".format(t.amount)}"
            holder.binding.tvAmount.setTextColor(0xFF388E3C.toInt())
            holder.binding.tvType.setTextColor(0xFF388E3C.toInt())
        }
        holder.binding.tvDate.text = t.date
        holder.binding.tvNote.text = t.note.ifEmpty { "" }
    }

    fun update(newList: MutableList<Transaction>) {
        list = newList
        notifyDataSetChanged()
    }
}
