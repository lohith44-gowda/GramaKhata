package com.example.gramakhata

import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper

class DatabaseHelper(context: Context) :
    SQLiteOpenHelper(context, "GramaKhataDB", null, 6) {

    override fun onCreate(db: SQLiteDatabase) {
        db.execSQL("""
            CREATE TABLE users(
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                phone TEXT UNIQUE,
                password TEXT,
                storeName TEXT,
                storePlace TEXT,
                storePhotoUri TEXT DEFAULT ''
            )
        """)
        // userId column links customers to their owner — fixes data sharing between users
        db.execSQL("""
            CREATE TABLE customers(
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                userId INTEGER NOT NULL,
                name TEXT,
                phone TEXT,
                photoUri TEXT DEFAULT ''
            )
        """)
        db.execSQL("""
            CREATE TABLE transactions(
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                customerId INTEGER,
                amount REAL,
                type TEXT,
                date TEXT,
                note TEXT DEFAULT ''
            )
        """)
    }

    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {
        db.execSQL("DROP TABLE IF EXISTS users")
        db.execSQL("DROP TABLE IF EXISTS customers")
        db.execSQL("DROP TABLE IF EXISTS transactions")
        onCreate(db)
    }

    // ── USER AUTH ──────────────────────────────────────────────
    fun registerUser(phone: String, password: String, storeName: String,
                     storePlace: String, storePhotoUri: String = ""): Boolean {
        val values = ContentValues().apply {
            put("phone", phone); put("password", password)
            put("storeName", storeName); put("storePlace", storePlace)
            put("storePhotoUri", storePhotoUri)
        }
        return try { writableDatabase.insertOrThrow("users", null, values) != -1L }
        catch (e: Exception) { false }
    }

    fun loginUser(phone: String, password: String): User? {
        val cursor = readableDatabase.rawQuery(
            "SELECT * FROM users WHERE phone=? AND password=?", arrayOf(phone, password))
        var user: User? = null
        if (cursor.moveToFirst())
            user = User(cursor.getInt(0), cursor.getString(1), cursor.getString(2),
                cursor.getString(3), cursor.getString(4), cursor.getString(5) ?: "")
        cursor.close()
        return user
    }

    fun getUserByPhone(phone: String): User? {
        val cursor = readableDatabase.rawQuery(
            "SELECT * FROM users WHERE phone=?", arrayOf(phone))
        var user: User? = null
        if (cursor.moveToFirst())
            user = User(cursor.getInt(0), cursor.getString(1), cursor.getString(2),
                cursor.getString(3), cursor.getString(4), cursor.getString(5) ?: "")
        cursor.close()
        return user
    }

    fun updatePassword(phone: String, newPassword: String): Boolean {
        val values = ContentValues().apply { put("password", newPassword) }
        return writableDatabase.update("users", values, "phone=?", arrayOf(phone)) > 0
    }

    fun updateStorePhoto(userId: Int, photoUri: String): Boolean {
        val values = ContentValues().apply { put("storePhotoUri", photoUri) }
        return writableDatabase.update("users", values, "id=?", arrayOf(userId.toString())) > 0
    }

    // ── CUSTOMERS (userId scoped — each user sees only their own) ──
    fun insertCustomer(userId: Int, name: String, phone: String, photoUri: String = ""): Boolean {
        val values = ContentValues().apply {
            put("userId", userId); put("name", name)
            put("phone", phone); put("photoUri", photoUri)
        }
        return writableDatabase.insert("customers", null, values) != -1L
    }

    fun getAllCustomers(userId: Int): MutableList<Customer> {
        val list = mutableListOf<Customer>()
        val cursor = readableDatabase.rawQuery(
            "SELECT * FROM customers WHERE userId=? ORDER BY name ASC", arrayOf(userId.toString()))
        while (cursor.moveToNext())
            list.add(Customer(cursor.getInt(0), cursor.getString(2),
                cursor.getString(3), cursor.getString(4) ?: ""))
        cursor.close()
        return list
    }

    fun getCustomerPhotoUris(userId: Int): List<String> {
        val list = mutableListOf<String>()
        val cursor = readableDatabase.rawQuery(
            "SELECT photoUri FROM customers WHERE userId=? AND photoUri != ''",
            arrayOf(userId.toString()))
        while (cursor.moveToNext()) list.add(cursor.getString(0))
        cursor.close()
        return list
    }

    fun deleteCustomer(id: Int) {
        writableDatabase.delete("customers", "id=?", arrayOf(id.toString()))
        writableDatabase.delete("transactions", "customerId=?", arrayOf(id.toString()))
    }

    fun updateCustomer(id: Int, name: String, phone: String, photoUri: String = "") {
        val values = ContentValues().apply {
            put("name", name); put("phone", phone); put("photoUri", photoUri)
        }
        writableDatabase.update("customers", values, "id=?", arrayOf(id.toString()))
    }

    // ── TRANSACTIONS ────────────────────────────────────────────
    fun addTransaction(customerId: Int, amount: Double, type: String, date: String, note: String = "") {
        val values = ContentValues().apply {
            put("customerId", customerId); put("amount", amount)
            put("type", type); put("date", date); put("note", note)
        }
        writableDatabase.insert("transactions", null, values)
    }

    fun getBalance(customerId: Int): Double {
        val cursor = readableDatabase.rawQuery(
            "SELECT type, amount FROM transactions WHERE customerId=?",
            arrayOf(customerId.toString()))
        var give = 0.0; var take = 0.0
        while (cursor.moveToNext()) {
            if (cursor.getString(0) == "GIVE") give += cursor.getDouble(1)
            else take += cursor.getDouble(1)
        }
        cursor.close()
        return give - take
    }

    fun getTransactions(customerId: Int): MutableList<Transaction> {
        val list = mutableListOf<Transaction>()
        val cursor = readableDatabase.rawQuery(
            "SELECT id,customerId,amount,type,date,note FROM transactions WHERE customerId=? ORDER BY id DESC",
            arrayOf(customerId.toString()))
        while (cursor.moveToNext())
            list.add(Transaction(cursor.getInt(0), cursor.getInt(1), cursor.getDouble(2),
                cursor.getString(3), cursor.getString(4), cursor.getString(5) ?: ""))
        cursor.close()
        return list
    }

    fun getAllDueSummary(userId: Int): List<Triple<Customer, Double, List<Transaction>>> =
        getAllCustomers(userId).map { c -> Triple(c, getBalance(c.id), getTransactions(c.id)) }
            .filter { it.second > 0 }.sortedByDescending { it.second }
}
