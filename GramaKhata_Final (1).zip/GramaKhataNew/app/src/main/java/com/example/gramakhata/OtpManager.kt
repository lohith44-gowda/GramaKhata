package com.example.gramakhata

import android.content.Context
import android.telephony.SmsManager
import android.os.Build
import android.widget.Toast
import kotlin.random.Random

object OtpManager {

    private var generatedOtp: String = ""
    private var otpPhone: String = ""
    private var otpExpiry: Long = 0L
    private const val OTP_VALIDITY_MS = 5 * 60 * 1000L // 5 minutes

    fun generateOtp(phone: String): String {
        generatedOtp = (100000 + Random.nextInt(900000)).toString()
        otpPhone = phone
        otpExpiry = System.currentTimeMillis() + OTP_VALIDITY_MS
        return generatedOtp
    }

    /** Send OTP directly via SMS — no user action needed */
    fun sendOtpDirectSms(context: Context, phone: String): Boolean {
        val otp = generateOtp(phone)
        val message = "Your Grama-Khata OTP is: $otp\nValid for 5 minutes. Do not share with anyone."
        return try {
            val smsManager = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                context.getSystemService(SmsManager::class.java)
            } else {
                @Suppress("DEPRECATION")
                SmsManager.getDefault()
            }
            smsManager.sendTextMessage(phone, null, message, null, null)
            true
        } catch (e: Exception) {
            Toast.makeText(context, "SMS failed: ${e.message}", Toast.LENGTH_LONG).show()
            false
        }
    }

    fun verifyOtp(phone: String, enteredOtp: String): OtpResult {
        return when {
            phone != otpPhone -> OtpResult.WRONG_PHONE
            System.currentTimeMillis() > otpExpiry -> OtpResult.EXPIRED
            enteredOtp.trim() == generatedOtp -> OtpResult.SUCCESS
            else -> OtpResult.WRONG_OTP
        }
    }

    fun clearOtp() {
        generatedOtp = ""; otpPhone = ""; otpExpiry = 0L
    }

    enum class OtpResult { SUCCESS, WRONG_OTP, EXPIRED, WRONG_PHONE }
}
